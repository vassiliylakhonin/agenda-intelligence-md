# Agenda Intelligence MD

[![PyPI version](https://img.shields.io/pypi/v/agenda-intelligence-md?style=flat-square)](https://pypi.org/project/agenda-intelligence-md/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![CI Status](https://github.com/vassiliylakhonin/agenda-intelligence-md/actions/workflows/ci.yml/badge.svg)](https://github.com/vassiliylakhonin/agenda-intelligence-md/actions)
[![GitHub stars](https://img.shields.io/github/stars/vassiliylakhonin/agenda-intelligence-md?style=flat-square)](https://github.com/vassiliylakhonin/agenda-intelligence-md/stargazers)

**A drop‑in cognition layer for AI agents that stops them from just summarizing news and starts producing decision‑ready analysis.**

> **Bottom line:** agents using this protocol move from *“monitor developments”* to *“watch these 3 indicators; if X happens, decision Y becomes urgent.”*

---

## 🚀 Quick start (OpenClaw)

1. **Install skill** (recommended):
   ```bash
   clawhub install agenda-intelligence
   ```
   Or copy `skills/agenda-intelligence/` into your workspace.

2. **Use in a prompt**:
   ```
   [skill:agenda-intelligence]
   Brief: "EU AI Act amendment adds new high‑risk categories."
   ```
   The agent will load the protocol, run the CLI, and return a compact brief.

3. **Or use the CLI directly** (after `pip install agenda-intelligence-md`):
   ```bash
   agenda-intelligence validate-brief examples/agenda-brief.json
   agenda-intelligence source-plan technology-ai
   ```

---

## 🎯 What it does

| Without Agenda‑Intelligence.md | With Agenda‑Intelligence.md |
|--------------------------------|--------------------------------|
| “Companies should monitor developments.” | “Watch for regulator guidance, first enforcement action, compliance deadline, and product redesigns. Treat as signal until those indicators appear.” |

The protocol forces the agent to answer:
- **Signal classification:** noise → weak signal → signal → structural shift → trigger event
- **What changed?** (fact)
- **Why it matters?** (incentives, leverage)
- **Who is affected?**
- **Main uncertainty?**
- **Scenarios & watch‑next indicators**

Result: shorter output, higher decision value.

---

## 🧠 Key features

- **Source Acquisition Layer** – tells the agent *which* source types to check before making claims (sanctions, regulation, elections, conflict, etc.).
- **AnalysisBank** – a memory layer that stores reusable reasoning patterns from good/bad outputs.
- **Regional lenses** – Central Asia & Caspian, Middle East, EU.
- **Sector lenses** – sanctions, export controls.
- **JSON schemas** – validate briefs, evidence packs, memory cards.
- **CLI & Python API** – `agenda-intelligence` command, `agent-manifest.json` for discovery.

---

## 📦 Installation

### From PyPI (when published)
```bash
pip install agenda-intelligence-md
```

### From GitHub Release
```bash
pip install https://github.com/vassiliylakhonin/agenda-intelligence-md/releases/download/v0.5.0/agenda_intelligence_md-0.5.0-py3-none-any.whl
```

### Editable install from source
```bash
git clone https://github.com/vassiliylakhonin/agenda-intelligence-md
cd agenda-intelligence-md
pip install -e .
```

---

## 🛠 CLI examples

```bash
agenda-intelligence --help
agenda-intelligence manifest
agenda-intelligence list-lenses
agenda-intelligence source-types
agenda-intelligence source-plan sanctions
agenda-intelligence validate-brief examples/agenda-brief.json
agenda-intelligence validate-evidence examples/source/evidence-pack.json
agenda-intelligence memory-search "sanctions routing"
```

---

## 📚 Documentation

- **Protocol:** [`Agenda-Intelligence.md`](Agenda-Intelligence.md) – the core reasoning workflow.
- **Quickstart:** [`docs/quickstart.md`](docs/quickstart.md)
- **Integrations:** [`docs/integrations/`](docs/integrations/) – Claude Code, OpenAI Codex, Cursor, MCP.
- **Evaluation:** [`docs/evaluation.md`](docs/evaluation.md) – how the scoring works.
- **Roadmap:** [`ROADMAP.md`](ROADMAP.md)

---

## 🏗 Repository structure

```
agenda-intelligence-md/
├─ src/agenda_intelligence/   # Python package
├─ schemas/                   # JSON schemas
├─ examples/                  # sample briefs, evidence packs
├─ analysis-bank/             # memory cards (failures & successes)
├─ skills/agenda-intelligence/ # OpenClaw skill wrapper
├─ docs/                      # guides & integration notes
└─ tests/                     # pytest suite
```

---

## 🤝 Contributing

Pull requests are welcome! Please:
1. Open an issue to discuss changes.
2. Create a feature branch (`feat/...`, `fix/...`).
3. Run `pytest` and ensure all tests pass.
4. Update docs if behavior changes.

See [`docs/quickstart.md`](docs/quickstart.md) for development setup.

---

## 📄 License

MIT – free for any use.

---

## 🔗 Related projects

- **[global-think-tank-analyst](https://github.com/vassiliylakhonin/global-think-tank-analyst)** – deeper policy‑risk memos for OpenClaw.

---

> **Why this exists:** Most agent‑written news analysis is a polished recap that doesn’t change any decision. This project gives agents a stricter workflow so their output actually helps someone decide, hedge, or act.
