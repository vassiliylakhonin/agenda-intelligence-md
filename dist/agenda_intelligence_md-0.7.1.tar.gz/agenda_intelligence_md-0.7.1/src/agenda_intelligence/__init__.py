"""Agenda Intelligence package."""

__version__ = "0.7.1"
