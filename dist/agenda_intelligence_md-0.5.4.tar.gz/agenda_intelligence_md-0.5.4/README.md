# Agenda Intelligence MD

[![PyPI version](https://img.shields.io/pypi/v/agenda-intelligence-md?style=flat-square)](https://pypi.org/project/agenda-intelligence-md/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![CI Status](https://github.com/vassiliylakhonin/agenda-intelligence-md/actions/workflows/ci.yml/badge.svg)](https://github.com/vassiliylakhonin/agenda-intelligence-md/actions)
[![GitHub stars](https://img.shields.io/github/stars/vassiliylakhonin/agenda-intelligence-md?style=flat-square)](https://github.com/vassiliylakhonin/agenda-intelligence-md/stargazers)

**A drop-in markdown cognition layer that turns news scanning into decision-ready analysis.**

> **Bottom line:** agents using this protocol move from *“monitor developments”* to *“watch these 3 indicators; if X happens, decision Y becomes urgent.”*

---

## Who it is for

- **Policy analysts & think‑tanks** – structured monitoring of regulatory and geopolitical signals.
- **Sanctions & compliance teams** – evidence‑backed briefs that satisfy audit requirements.
- **Market‑risk analysts** – concise impact snapshots for faster investment decisions.
- **Founders & operators** – external chaos turned into clear strategic inputs.
- **AI agents** – any LLM‑based system that needs to analyze public agenda without drifting into generic summaries.

---

## Quick install

### From PyPI
```bash
pip install agenda-intelligence-md
```

### From GitHub Release (v0.5.4)
```bash
pip install https://github.com/vassiliylakhonin/agenda-intelligence-md/releases/download/v0.5.4/agenda_intelligence_md-0.5.4-py3-none-any.whl
```

### Editable install from source
```bash
git clone https://github.com/vassiliylakhonin/agenda-intelligence-md
cd agenda-intelligence-md
pip install -e .
```

---

## CLI happy path (aha‑moment in 5‑10 min)

The **`start`** command is the primary onboarding entry‑point. It prints a trimmed source plan, a brief template, and next commands.

```bash
# 1. Onboard with a source category
agenda-intelligence start technology-ai

# Output: trimmed source plan + brief template + next commands

# 2. Validate a bundled example brief
agenda-intelligence validate-brief examples/agenda-brief.json

# 3. Score a JSON brief (structural quality check)
agenda-intelligence score examples/agenda-brief.json

# 4. Add an evidence pack for claim-level evidence discipline
agenda-intelligence score examples/agenda-brief.json --evidence examples/source/evidence-pack.json

# 5. Or score a before/after markdown example
agenda-intelligence score examples/before-after/eu-ai-act.md
```

> **Scorer status:** the `score` command now scores JSON briefs with a
> heuristic 0-100 structural rubric, can include an evidence pack for
> claim-level support feedback, and still supports before/after markdown
> examples. It does not verify factual truthfulness.

**Demo output** (what you see after `start`):
```text
=== Trimmed source plan ===
{
  "must_check": ["tech‑release", "policy‑update", "market‑data"],
  "watch_indicators": ["regulation draft", "enforcement action"]
}

=== Brief template (fill in) ===
{
  "bottom_line": "<summary>",
  "signal_classification": "<signal>",
  "what_changed": "<what changed>",
  "main_uncertainty": "<main uncertainty>",
  "watch_next": ["<indicator 1>", "<indicator 2>"]
}
```

---

## Protocol · Source Policy · Schemas

| Layer | Purpose | Status |
|-------|----------|--------|
| **Markdown protocol** (`Agenda-Intelligence.md`) | Core reasoning workflow (signal classification, watch‑next, etc.) | ✅ Stable |
| **Source Acquisition Layer** | Tells the agent *which* source types to check before making claims (sanctions, regulation, elections, conflict, etc.) | ✅ Stable |
| **JSON schemas** | Validate briefs, evidence packs, memory cards | ✅ Stable |
| **AnalysisBank** | Memory layer that stores reusable reasoning patterns from good/bad outputs | ✅ Stable |
| **Regional & Sector lenses** | Central Asia & Caspian, Middle East, EU; sanctions, export controls | ✅ Stable |

---

## Stable today vs Experimental

### ✅ Stable today
- **Markdown protocol** (`Agenda-Intelligence.md`) – core reasoning workflow.
- **JSON schemas** – validation for briefs, evidence packs, memory cards.
- **CLI validation** – `validate-brief`, `validate-evidence`, `validate-manifest`.
- **Source plans** – `source-plan`, `list-source-packs`, `source-types`.
- **Guided start** – `start` command prints trimmed plan + brief template.
- **Brief scoring** – `score examples/agenda-brief.json` returns a heuristic 0-100 structural quality score; add `--evidence` for claim-level evidence feedback.
- **Evaluation toolkit** – `evals/rubric.md`, `evals/llm_judge_prompt.txt`, `evals/human_checklist.md`, `evals/cases/*.json`.
- **MCP read tools** – `validate_brief`, `validate_evidence`, `get_protocol`, `list_lenses`, `get_lens`, `source_plan`.

### 🧪 Experimental / Planned
- **MCP transport/server** – read-only tool functions exist, but a full HTTP/WebSocket server is still on the roadmap (`docs/integrations/mcp.md`).
- **Fetch command** – stub in CLI, full evidence‑pack retrieval not implemented.
- **Truthfulness evaluation** – not implemented; current scoring checks structure and protocol signals.
- **Generate‑brief** – not yet exposed; use `start` + manual template fill.

> **Note:** The project is young. Stable parts are ready for production use; experimental bits are usable for testing but may change.

---

## Examples

- **Source‑backed briefs** (with evidence mode & source plans):  
  `examples/source-backed/eu-ai-act.md`, `sanctions-routing.md`, `red-sea-shipping.md`
- **Classic examples:** `examples/hormuz_strait_brief.md`, `eu-brief.md`, `central-asia-caspian-brief.md`
- **Before/after:** `examples/before-after/` – shows the delta when the protocol is applied.

---

## Documentation

| Resource | Link |
|----------|------|
| **Quickstart** | [`docs/quickstart.md`](docs/quickstart.md) |
| **End‑to‑end tutorial** | [`docs/tutorial.md`](docs/tutorial.md) |
| **Evaluation assets** | [`evals/`](evals/) – rubric, LLM judge prompt, human checklist, sample cases |
| **Use‑cases** | [`docs/use-cases/`](docs/use-cases/) – policy monitoring, sanctions compliance, market risk, founder context |
| **Integrations** | [`docs/integrations/`](docs/integrations/) – Claude Code, OpenAI Codex, Cursor, MCP |
| **Roadmap** | [`ROADMAP.md`](ROADMAP.md) |
| **Changelog** | [`CHANGELOG.md`](CHANGELOG.md) |

---

## Repository structure

```
agenda-intelligence-md/
├─ src/agenda_intelligence/   # Python package
├─ schemas/                   # JSON schemas
├─ examples/                  # sample briefs, evidence packs, source‑backed examples
├─ analysis-bank/             # memory cards (failures & successes)
├─ evals/                     # evaluation rubric, LLM judge, human checklist, cases
├─ docs/                      # guides, tutorials, use‑cases, integrations
├─ skills/agenda-intelligence/ # OpenClaw skill wrapper
└─ tests/                     # pytest suite
```

---

## Roadmap (high‑level)

- **v0.6** – Full MCP server exposing current Python tool functions via HTTP/WebSocket.
- **v0.7** – Promote `score_output` to rubric-based quality scoring and wire it into MCP.
- **v0.8** – Automated CI quality gate using the evaluation toolkit.
- **v1.0** – Stable API, broader adoption‑channel support, production‑grade MCP.

---

## Contributing

Pull requests are welcome! Please:
1. Open an issue to discuss changes.
2. Create a feature branch (`feat/...`, `fix/...`).
3. Run `pytest` and ensure all tests pass.
4. Update docs if behavior changes.

---

## License

MIT – free for any use.

---

## Why this exists

Most agent‑written news analysis is a polished recap that doesn’t change any decision. This project gives agents a stricter workflow so their output actually helps someone decide, hedge, or act.
