"""Agenda Intelligence package."""

__version__ = "0.5.2"
